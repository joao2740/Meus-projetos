# 📦 Cadastro App

Aplicativo mobile desenvolvido com **React Native + Expo + TypeScript** para cadastro de itens/produtos.

---

## 📋 Sobre o Projeto

Este projeto foi desenvolvido como atividade prática de React Native, implementando uma tela de cadastro funcional com validações e feedback visual ao usuário.

## ✨ Funcionalidades

- ✅ Formulário de cadastro com **Nome**, **Preço** e **Descrição**
- ✅ Validação de campos obrigatórios com mensagens de erro
- ✅ Modal de confirmação exibindo os dados cadastrados
- ✅ Log dos dados no console após o cadastro
- ✅ Limpeza automática do formulário após o cadastro

## 🛠️ Tecnologias

| Tecnologia       | Versão   |
|------------------|----------|
| React Native     | 0.73.4   |
| Expo             | ~50.0.0  |
| TypeScript       | ^5.1.3   |
| React            | 18.2.0   |

## 📁 Estrutura de Pastas

```
cadastro-app/
├── App.tsx                         # Ponto de entrada da aplicação
├── app.json                        # Configurações do Expo
├── tsconfig.json                   # Configurações do TypeScript
├── package.json                    # Dependências do projeto
└── src/
    ├── components/
    │   ├── CampoTexto.tsx          # Componente de input reutilizável
    │   ├── BotaoPrimario.tsx       # Componente de botão
    │   └── ModalSucesso.tsx        # Modal de confirmação de cadastro
    ├── screens/
    │   └── CadastroScreen.tsx      # Tela principal de cadastro
    ├── types/
    │   └── index.ts                # Tipos e interfaces TypeScript
    └── utils/
        └── validacao.ts            # Funções de validação do formulário
```

## 🚀 Como Executar

### Pré-requisitos

- [Node.js](https://nodejs.org/) (versão 18 ou superior)
- [Expo CLI](https://docs.expo.dev/get-started/installation/)
- App **Expo Go** no celular (iOS ou Android)

### Instalação

```bash
# Clone o repositório
git clone https://github.com/SEU_USUARIO/cadastro-app.git

# Entre na pasta do projeto
cd cadastro-app

# Instale as dependências
npm install

# Inicie o servidor de desenvolvimento
npx expo start
```

### Executando no dispositivo

Após rodar `npx expo start`, escaneie o QR Code com o app **Expo Go** no seu celular.

## 📱 Comportamento do App

1. O usuário preenche os campos **Nome**, **Preço** e **Descrição**
2. Ao pressionar **Cadastrar Item**, os campos são validados
3. Se houver erros, mensagens são exibidas abaixo de cada campo
4. Se tudo for válido:
   - Um **modal de sucesso** é exibido com os dados do item
   - Os dados são **impressos no console** (abra o terminal para ver)
   - O formulário é **limpo** automaticamente

## 🧪 Regras de Validação

| Campo      | Regra                                      |
|------------|--------------------------------------------|
| Nome       | Obrigatório, mínimo 3 caracteres           |
| Preço      | Obrigatório, número maior que zero         |
| Descrição  | Obrigatória, mínimo 10 caracteres          |

---

Desenvolvido com ❤️ usando React Native + TypeScript
