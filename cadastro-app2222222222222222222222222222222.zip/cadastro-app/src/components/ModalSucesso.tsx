import React from 'react';
import {
  Modal,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import { Item } from '../types';
import { formatarPreco } from '../utils/validacao';

interface ModalSucessoProps {
  visivel: boolean;
  item: Item | null;
  onFechar: () => void;
}

const ModalSucesso: React.FC<ModalSucessoProps> = ({
  visivel,
  item,
  onFechar,
}) => {
  if (!item) return null;

  return (
    <Modal
      visible={visivel}
      transparent
      animationType="fade"
      onRequestClose={onFechar}
    >
      <View style={styles.overlay}>
        <View style={styles.card}>
          <View style={styles.iconeContainer}>
            <Text style={styles.icone}>✓</Text>
          </View>
          <Text style={styles.titulo}>Cadastro Realizado!</Text>
          <Text style={styles.subtitulo}>Item registrado com sucesso.</Text>

          <View style={styles.divisor} />

          <View style={styles.detalhe}>
            <Text style={styles.detalheLabel}>Nome</Text>
            <Text style={styles.detalheValor}>{item.nome}</Text>
          </View>
          <View style={styles.detalhe}>
            <Text style={styles.detalheLabel}>Preço</Text>
            <Text style={styles.detalheValorDestaque}>
              {formatarPreco(String(item.preco))}
            </Text>
          </View>
          <View style={styles.detalhe}>
            <Text style={styles.detalheLabel}>Descrição</Text>
            <Text style={styles.detalheValor}>{item.descricao}</Text>
          </View>

          <TouchableOpacity style={styles.botao} onPress={onFechar}>
            <Text style={styles.botaoTexto}>Novo Cadastro</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  card: {
    backgroundColor: '#1e293b',
    borderRadius: 20,
    padding: 28,
    width: '100%',
    maxWidth: 380,
    borderWidth: 1,
    borderColor: '#334155',
  },
  iconeContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#022c22',
    borderWidth: 2,
    borderColor: '#34d399',
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    marginBottom: 16,
  },
  icone: {
    fontSize: 26,
    color: '#34d399',
    fontWeight: '700',
  },
  titulo: {
    fontSize: 22,
    fontWeight: '700',
    color: '#f1f5f9',
    textAlign: 'center',
  },
  subtitulo: {
    fontSize: 14,
    color: '#94a3b8',
    textAlign: 'center',
    marginTop: 4,
    marginBottom: 20,
  },
  divisor: {
    height: 1,
    backgroundColor: '#334155',
    marginBottom: 16,
  },
  detalhe: {
    marginBottom: 12,
  },
  detalheLabel: {
    fontSize: 11,
    color: '#64748b',
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 2,
  },
  detalheValor: {
    fontSize: 15,
    color: '#e2e8f0',
  },
  detalheValorDestaque: {
    fontSize: 18,
    color: '#38bdf8',
    fontWeight: '700',
  },
  botao: {
    backgroundColor: '#38bdf8',
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 20,
  },
  botaoTexto: {
    color: '#0f172a',
    fontSize: 15,
    fontWeight: '700',
  },
});

export default ModalSucesso;
