import React from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  ActivityIndicator,
  ViewStyle,
} from 'react-native';

interface BotaoPrimarioProps {
  titulo: string;
  onPress: () => void;
  carregando?: boolean;
  desabilitado?: boolean;
  estilo?: ViewStyle;
}

const BotaoPrimario: React.FC<BotaoPrimarioProps> = ({
  titulo,
  onPress,
  carregando = false,
  desabilitado = false,
  estilo,
}) => {
  return (
    <TouchableOpacity
      style={[
        styles.botao,
        (desabilitado || carregando) && styles.botaoDesabilitado,
        estilo,
      ]}
      onPress={onPress}
      disabled={desabilitado || carregando}
      activeOpacity={0.85}
    >
      {carregando ? (
        <ActivityIndicator color="#0f172a" size="small" />
      ) : (
        <Text style={styles.texto}>{titulo}</Text>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  botao: {
    backgroundColor: '#38bdf8',
    borderRadius: 12,
    paddingVertical: 15,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#38bdf8',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    elevation: 6,
  },
  botaoDesabilitado: {
    backgroundColor: '#475569',
    shadowOpacity: 0,
    elevation: 0,
  },
  texto: {
    color: '#0f172a',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
});

export default BotaoPrimario;
