import React from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TextInputProps,
} from 'react-native';

interface CampoTextoProps extends TextInputProps {
  label: string;
  erro?: string;
  obrigatorio?: boolean;
}

const CampoTexto: React.FC<CampoTextoProps> = ({
  label,
  erro,
  obrigatorio = false,
  ...props
}) => {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>
        {label}
        {obrigatorio && <Text style={styles.asterisco}> *</Text>}
      </Text>
      <TextInput
        style={[styles.input, erro ? styles.inputErro : null]}
        placeholderTextColor="#9ca3af"
        {...props}
      />
      {erro ? <Text style={styles.textoErro}>{erro}</Text> : null}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#e2e8f0',
    marginBottom: 6,
    letterSpacing: 0.3,
  },
  asterisco: {
    color: '#f87171',
  },
  input: {
    backgroundColor: '#1e293b',
    borderWidth: 1,
    borderColor: '#334155',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    color: '#f1f5f9',
  },
  inputErro: {
    borderColor: '#f87171',
    borderWidth: 1.5,
  },
  textoErro: {
    fontSize: 12,
    color: '#f87171',
    marginTop: 4,
    marginLeft: 2,
  },
});

export default CampoTexto;
