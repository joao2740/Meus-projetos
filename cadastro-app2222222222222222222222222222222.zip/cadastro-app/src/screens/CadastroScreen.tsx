import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
} from 'react-native';

import CampoTexto from '../components/CampoTexto';
import BotaoPrimario from '../components/BotaoPrimario';
import ModalSucesso from '../components/ModalSucesso';

import { FormularioItem, ErrosFormulario, Item } from '../types';
import { validarFormulario, formularioValido } from '../utils/validacao';

// Estado inicial do formulário
const FORMULARIO_INICIAL: FormularioItem = {
  nome: '',
  preco: '',
  descricao: '',
};

const CadastroScreen: React.FC = () => {
  // Estado do formulário
  const [formulario, setFormulario] = useState<FormularioItem>(FORMULARIO_INICIAL);

  // Estado dos erros de validação
  const [erros, setErros] = useState<ErrosFormulario>({});

  // Estado do modal de sucesso
  const [modalVisivel, setModalVisivel] = useState<boolean>(false);

  // Item cadastrado para exibir no modal
  const [itemCadastrado, setItemCadastrado] = useState<Item | null>(null);

  // Estado de carregamento do botão
  const [carregando, setCarregando] = useState<boolean>(false);

  /**
   * Atualiza um campo específico do formulário
   */
  const atualizarCampo = (campo: keyof FormularioItem, valor: string): void => {
    setFormulario(prev => ({ ...prev, [campo]: valor }));
    // Remove o erro do campo ao digitar
    if (erros[campo]) {
      setErros(prev => ({ ...prev, [campo]: undefined }));
    }
  };

  /**
   * Processa o envio do formulário
   */
  const handleCadastrar = (): void => {
    // Valida os campos
    const errosEncontrados = validarFormulario(formulario);

    if (!formularioValido(errosEncontrados)) {
      setErros(errosEncontrados);
      return;
    }

    setCarregando(true);

    // Simula processamento assíncrono
    setTimeout(() => {
      const novoItem: Item = {
        id: Date.now().toString(),
        nome: formulario.nome.trim(),
        preco: parseFloat(formulario.preco.replace(',', '.')),
        descricao: formulario.descricao.trim(),
        dataCadastro: new Date(),
      };

      // Exibe os dados no console (requisito da atividade)
      console.log('=== NOVO ITEM CADASTRADO ===');
      console.log('ID:', novoItem.id);
      console.log('Nome:', novoItem.nome);
      console.log('Preço: R$', novoItem.preco.toFixed(2));
      console.log('Descrição:', novoItem.descricao);
      console.log('Data:', novoItem.dataCadastro.toLocaleString('pt-BR'));
      console.log('===========================');
      console.log(JSON.stringify(novoItem, null, 2));

      setItemCadastrado(novoItem);
      setModalVisivel(true);
      setCarregando(false);
    }, 600);
  };

  /**
   * Limpa o formulário após o modal fechar
   */
  const handleFecharModal = (): void => {
    setModalVisivel(false);
    setFormulario(FORMULARIO_INICIAL);
    setErros({});
    setItemCadastrado(null);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        style={styles.keyboardView}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView
          contentContainerStyle={styles.scroll}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Cabeçalho */}
          <View style={styles.cabecalho}>
            <View style={styles.badgeContainer}>
              <Text style={styles.badge}>NOVO ITEM</Text>
            </View>
            <Text style={styles.titulo}>Cadastro de Produto</Text>
            <Text style={styles.subtitulo}>
              Preencha os campos abaixo para registrar um novo item no sistema.
            </Text>
          </View>

          {/* Formulário */}
          <View style={styles.formulario}>
            <CampoTexto
              label="Nome do Item"
              placeholder="Ex: Notebook Dell Inspiron"
              value={formulario.nome}
              onChangeText={(texto) => atualizarCampo('nome', texto)}
              erro={erros.nome}
              obrigatorio
              autoCapitalize="words"
              returnKeyType="next"
            />

            <CampoTexto
              label="Preço (R$)"
              placeholder="Ex: 2499.90"
              value={formulario.preco}
              onChangeText={(texto) => atualizarCampo('preco', texto)}
              erro={erros.preco}
              obrigatorio
              keyboardType="decimal-pad"
              returnKeyType="next"
            />

            <CampoTexto
              label="Descrição"
              placeholder="Descreva as características do item..."
              value={formulario.descricao}
              onChangeText={(texto) => atualizarCampo('descricao', texto)}
              erro={erros.descricao}
              obrigatorio
              multiline
              numberOfLines={4}
              textAlignVertical="top"
              style={{ minHeight: 100, paddingTop: 12 }}
            />

            <Text style={styles.legenda}>
              <Text style={styles.asteriscoLegenda}>* </Text>
              Campos obrigatórios
            </Text>

            <BotaoPrimario
              titulo="Cadastrar Item"
              onPress={handleCadastrar}
              carregando={carregando}
              estilo={styles.botaoCadastro}
            />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      {/* Modal de sucesso */}
      <ModalSucesso
        visivel={modalVisivel}
        item={itemCadastrado}
        onFechar={handleFecharModal}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  keyboardView: {
    flex: 1,
  },
  scroll: {
    flexGrow: 1,
    padding: 24,
    paddingTop: 40,
  },
  cabecalho: {
    marginBottom: 32,
  },
  badgeContainer: {
    alignSelf: 'flex-start',
    marginBottom: 12,
  },
  badge: {
    fontSize: 11,
    fontWeight: '700',
    color: '#38bdf8',
    letterSpacing: 2,
    backgroundColor: '#0c2238',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: '#1e4a6e',
    overflow: 'hidden',
  },
  titulo: {
    fontSize: 30,
    fontWeight: '800',
    color: '#f1f5f9',
    marginBottom: 8,
    letterSpacing: -0.5,
  },
  subtitulo: {
    fontSize: 14,
    color: '#64748b',
    lineHeight: 20,
  },
  formulario: {
    backgroundColor: '#1e293b',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: '#334155',
  },
  legenda: {
    fontSize: 12,
    color: '#64748b',
    marginBottom: 20,
    marginTop: 4,
  },
  asteriscoLegenda: {
    color: '#f87171',
  },
  botaoCadastro: {
    marginTop: 4,
  },
});

export default CadastroScreen;
