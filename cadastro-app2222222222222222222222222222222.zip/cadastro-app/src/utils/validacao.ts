import { FormularioItem, ErrosFormulario } from '../types';

export function validarFormulario(dados: FormularioItem): ErrosFormulario {
  const erros: ErrosFormulario = {};

  if (!dados.nome.trim()) {
    erros.nome = 'O nome do item é obrigatório.';
  } else if (dados.nome.trim().length < 3) {
    erros.nome = 'O nome deve ter pelo menos 3 caracteres.';
  }

  if (!dados.preco.trim()) {
    erros.preco = 'O preço é obrigatório.';
  } else {
    const precoNumerico = parseFloat(dados.preco.replace(',', '.'));
    if (isNaN(precoNumerico) || precoNumerico <= 0) {
      erros.preco = 'Informe um preço válido maior que zero.';
    }
  }

  if (!dados.descricao.trim()) {
    erros.descricao = 'A descrição é obrigatória.';
  } else if (dados.descricao.trim().length < 10) {
    erros.descricao = 'A descrição deve ter pelo menos 10 caracteres.';
  }

  return erros;
}

export function formularioValido(erros: ErrosFormulario): boolean {
  return Object.keys(erros).length === 0;
}

export function formatarPreco(valor: string): string {
  const numero = parseFloat(valor.replace(',', '.'));
  if (isNaN(numero)) return valor;
  return numero.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}
