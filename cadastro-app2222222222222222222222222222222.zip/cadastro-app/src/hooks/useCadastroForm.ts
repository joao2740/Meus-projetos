// src/hooks/useCadastroForm.ts

import { useState } from 'react';
import { Item, FormErrors } from '../types/item';

const INITIAL_FORM: Item = {
  nome: '',
  preco: '',
  descricao: '',
};

export function useCadastroForm() {
  const [form, setForm] = useState<Item>(INITIAL_FORM);
  const [errors, setErrors] = useState<FormErrors>({});
  const [sucesso, setSucesso] = useState(false);

  const handleChange = (campo: keyof Item, valor: string) => {
    setForm(prev => ({ ...prev, [campo]: valor }));

    // Limpa o erro do campo ao digitar
    if (errors[campo]) {
      setErrors(prev => ({ ...prev, [campo]: undefined }));
    }

    // Limpa a mensagem de sucesso ao editar
    if (sucesso) {
      setSucesso(false);
    }
  };

  const validar = (): boolean => {
    const novosErros: FormErrors = {};

    if (!form.nome.trim()) {
      novosErros.nome = 'O nome do item é obrigatório.';
    }

    if (!form.preco.trim()) {
      novosErros.preco = 'O preço é obrigatório.';
    } else if (isNaN(Number(form.preco.replace(',', '.')))) {
      novosErros.preco = 'Digite um preço válido (ex: 29.90).';
    } else if (Number(form.preco.replace(',', '.')) <= 0) {
      novosErros.preco = 'O preço deve ser maior que zero.';
    }

    if (!form.descricao.trim()) {
      novosErros.descricao = 'A descrição é obrigatória.';
    }

    setErrors(novosErros);
    return Object.keys(novosErros).length === 0;
  };

  const handleSubmit = () => {
    if (!validar()) return;

    const itemCadastrado: Item = {
      nome: form.nome.trim(),
      preco: form.preco.replace(',', '.'),
      descricao: form.descricao.trim(),
    };

    console.log('=== ITEM CADASTRADO ===');
    console.log(JSON.stringify(itemCadastrado, null, 2));
    console.log('======================');

    setSucesso(true);
    setForm(INITIAL_FORM);
    setErrors({});
  };

  return {
    form,
    errors,
    sucesso,
    handleChange,
    handleSubmit,
  };
}
