export interface Item {
  id: string;
  nome: string;
  preco: number;
  descricao: string;
  dataCadastro: Date;
}

export interface FormularioItem {
  nome: string;
  preco: string;
  descricao: string;
}

export interface ErrosFormulario {
  nome?: string;
  preco?: string;
  descricao?: string;
}
