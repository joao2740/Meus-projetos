// src/types/item.ts

export interface Item {
  nome: string;
  preco: string;
  descricao: string;
}

export interface FormErrors {
  nome?: string;
  preco?: string;
  descricao?: string;
}
