import React from 'react';
import { StatusBar } from 'expo-status-bar';
import CadastroScreen from './src/screens/CadastroScreen';

export default function App() {
  return (
    <>
      <StatusBar style="light" backgroundColor="#0f172a" />
      <CadastroScreen />
    </>
  );
}
